<?php

function send_mail($to,$subject,$message){
	require 'PhpMailer/class.phpmailer.php';
	require 'PhpMailer/class.smtp.php';
	$mail = new PHPMailer;
	$mail->setFrom('assignment.rvce@gmail.com');
	$mail->addAddress($to);
	$mail->Subject = $subject;
	$mail->Body = $message;
	$mail->IsSMTP();
	$mail->isHTML(true);
	$mail->SMTPSecure = 'ssl';
	$mail->Host = 'ssl://smtp.gmail.com';
	$mail->SMTPAuth = true;
	$mail->Port = 465;

	//Set your existing gmail address as user name
	$mail->Username = 'assignment.rvce@gmail.com';

	//Set the password of your gmail address here
	$mail->Password = 'ASSIGNMENT*RVCE*1999';
	if(!$mail->send()) {
	 return false;
	} else {
	 return true;
	}
}
/*$to="g1suro82@gmail.com";
$subject="Testing the mail function.";
$message="Testing complete:";
if(send_mail($to,$subject,$message))
	echo "Email sent.";
else 
	echo "Could not send email.";*/
?>